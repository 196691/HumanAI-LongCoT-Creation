# -*- coding: utf-8 -*-
# 首轮判定 vs 盲判复检：逐窗比对 + 分歧分类
# A=行为翻转 B=仅元/泛化类差异 C=作品归属分歧
# C类细分：C1复检扩充 C2作品转元/泛化类 C3真冲突 C4复检缩减
import pandas as pd, re

# ===== 参数区 =====
N_WORKS = 0                # 定稿作品数N
META, GENERAL = 'M', 'G'   # 元活动类/泛化兜底类代号
ORIG_CSV = '【首轮判定总表.csv】'
RECHECK_PATTERN = '【复检批次目录】/批次{n}.csv'
N_BATCH = 0                # 复检批次数
OUT_CSV = '【输出】/分歧分类.csv'

WSET = {f'W{i:02d}' for i in range(1, N_WORKS + 1)}
WORKS = WSET | {META, GENERAL}

def split_set(s):
    parts = re.split(r'[+＋、]', str(s))
    return set(w.strip() for w in parts
               if w.strip() and w.strip() not in ('待定', '无'))

orig = pd.read_csv(ORIG_CSV, dtype=str).fillna('')
orig['窗口ID'] = orig['窗口ID'].astype(int)
rows = []
for n in range(1, N_BATCH + 1):
    df = pd.read_csv(RECHECK_PATTERN.format(n=n), dtype=str)
    df = df.fillna('')
    df['窗口ID'] = df['窗口ID'].astype(int)
    df.columns = ['窗口ID', '归属2', '创作行为2', '状态2',
                  '有效片段2', '置信度2', '理由2']
    for _, r in orig.merge(df, on='窗口ID').iterrows():
        s1, s2 = split_set(r['归属']), split_set(r['归属2'])
        if s1 == s2 and r['创作行为'] == r['创作行为2']:
            continue
        w1, w2 = s1 & WSET, s2 & WSET
        if w1 == w2 and (s1 - WSET) == (s2 - WSET):
            typ, sub = 'A行为翻转', ''
        elif w1 == w2:
            typ, sub = 'B仅元泛化类差异', ''
        else:
            typ = 'C作品分歧'
            if not w2:
                sub = 'C2作品转元泛化类'
            elif not w1:
                sub = 'C3真冲突'
            elif w1 <= w2:
                sub = 'C1复检扩充'
            elif w2 < w1:
                sub = 'C4复检缩减'
            else:
                sub = 'C3真冲突'
        rows.append(dict(
            批次=n, 窗口ID=r['窗口ID'], 类型=typ, 子类=sub,
            原归属=r['归属'], 复检归属=r['归属2'],
            原行为=r['创作行为'], 复检行为=r['创作行为2'],
            原置信=r['置信度'], 复检置信=r['置信度2'],
            复检理由=r['理由2'][:400], 原理由=r['理由'][:400]))

out = pd.DataFrame(rows)
out.to_csv(OUT_CSV, index=False, encoding='utf-8-sig')
print(out['类型'].value_counts())
# C3/C4 → 人工逐窗仲裁；A类按预设口径批量校准；
# B/C1/C2按规则采纳复检
