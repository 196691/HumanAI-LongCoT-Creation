# -*- coding: utf-8 -*-
# 归档完整性校验：每窗 x 每个归属码，
# 在对应归属文件夹中须有副本（整窗或片段）
import os, re
import pandas as pd

# ===== 参数区 =====
PROC = '【过程包目录】'
FINAL_TABLE = '【归属终表.csv】'
# 归属码 -> 文件夹名映射，按本数据集补全：
WFOLDER = {'W01': '【W01文件夹名】',
           'M': '【元活动类文件夹】',
           'G': '【泛化类文件夹】'}

PAT = re.compile(r'^(?:(?:W\d{2}|[MG])\+?)+_(\d{3})_')

idx = {}
for folder in os.listdir(PROC):
    fp = f'{PROC}/{folder}'
    if not os.path.isdir(fp):
        continue
    d = {}
    for fn in os.listdir(fp):
        m = PAT.match(fn)
        if m:
            d.setdefault(int(m.group(1)), []).append(fn)
    idx[folder] = d

t = pd.read_csv(FINAL_TABLE, dtype=str).fillna('')
t['窗口ID'] = t['窗口ID'].astype(int)
missing, checked = [], 0
for _, r in t.iterrows():
    attrs = [x.strip() for x in r['最终归属'].split('+')]
    for a in attrs:
        checked += 1
        folder = WFOLDER[a]
        if r['窗口ID'] not in idx.get(folder, {}):
            missing.append(f"{r['窗口ID']:03d} 缺 {a}")

print(f'归属-窗校验项: {checked} | 缺失: {len(missing)}')
for x in missing[:50]:
    print(' !', x)
