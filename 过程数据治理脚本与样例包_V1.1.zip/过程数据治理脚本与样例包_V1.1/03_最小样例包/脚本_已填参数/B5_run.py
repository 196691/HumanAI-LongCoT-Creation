# -*- coding: utf-8 -*-
# 归档完整性校验：每窗×每个归属码，在对应归属文件夹中须有副本（整窗或片段）
import os, re
import pandas as pd

# ===== 参数区 =====
PROC = '/tmp/mini/过程包'
FINAL_TABLE = '/tmp/mini/终表.csv'
WFOLDER = {'W01':'W01_思想方案','W02':'W02_登高思维','M':'M_元活动','G':'G_泛化'}

idx = {}
for folder in os.listdir(PROC):
    fp = f'{PROC}/{folder}'
    if not os.path.isdir(fp): continue
    d = {}
    for fn in os.listdir(fp):
        m = re.match(r'^(?:(?:W\d{2}|[MG])\+?)+_(\d{3})_', fn)
        if m: d.setdefault(int(m.group(1)), []).append(fn)
    idx[folder] = d

t = pd.read_csv(FINAL_TABLE, dtype=str).fillna('')
t['窗口ID'] = t['窗口ID'].astype(int)
missing, checked = [], 0
for _, r in t.iterrows():
    for a in [x.strip() for x in r['最终归属'].split('+')]:
        checked += 1
        if r['窗口ID'] not in idx.get(WFOLDER[a], {}):
            missing.append(f"{r['窗口ID']:03d} 缺 {a}")
print(f'归属-窗校验项: {checked} | 缺失: {len(missing)}')
for x in missing[:50]: print(' !', x)
