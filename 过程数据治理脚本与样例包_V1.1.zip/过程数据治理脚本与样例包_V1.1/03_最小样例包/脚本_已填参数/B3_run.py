# -*- coding: utf-8 -*-
# 窗口规范化改名：序号_日期_归属简写_关键词.json + 改名对照表（可回查、幂等）
import pandas as pd, re, os

# ===== 参数区 =====
BASE = '/tmp/mini/base'
FINAL_TABLE = '/tmp/mini/终表.csv'      # 含 窗口ID/所在文件包/原文件名/起始时间/最终归属/创作行为/状态
SHORT = {'W01':'思想方案','W02':'登高思维','M':'元活动','G':'泛化'}

ILLEGAL = r'[\\/:*?"<>|《》（）()，,。.、\s]+'
def clean(s, n=22):
    s = re.sub(ILLEGAL, '', str(s))
    return s[:n] if s else ''

t = pd.read_csv(FINAL_TABLE, dtype=str).fillna('')
t['窗口ID'] = t['窗口ID'].astype(int)
used, rows = {}, []
for _, r in t.iterrows():
    wid = r['窗口ID']; date = str(r['起始时间'])[:10].replace('-', '')
    works = [w.strip() for w in re.split(r'[+＋]', r['最终归属'])]
    kw = clean(''.join(SHORT.get(w, w) for w in works[:2]), 16) or '窗口'
    new = f"{wid:03d}_{date}_{'_'.join(works)}_{kw}.json"
    key = (r['所在文件包'], new)
    if key in used:
        used[key] += 1; new = new[:-5] + f"_{used[key]}.json"
    else:
        used[key] = 0
    rows.append(dict(窗口ID=wid, 所在文件包=r['所在文件包'], 原文件名=r['原文件名'],
                     新文件名=new, 最终归属=r['最终归属'], 创作行为=r['创作行为'], 状态=r['状态']))
m = pd.DataFrame(rows)
ok, miss = 0, []
for _, r in m.iterrows():
    p_old = f"{BASE}/{r['所在文件包']}/{r['原文件名']}"
    p_new = f"{BASE}/{r['所在文件包']}/{r['新文件名']}"
    if os.path.exists(p_old): os.rename(p_old, p_new); ok += 1
    elif os.path.exists(p_new): ok += 1      # 幂等：已改过
    else: miss.append((r['窗口ID'], r['原文件名']))
m.to_csv(f'{BASE}/改名对照表.csv', index=False, encoding='utf-8-sig')
print(f'改名成功 {ok}/{len(m)}，缺失 {len(miss)}')
