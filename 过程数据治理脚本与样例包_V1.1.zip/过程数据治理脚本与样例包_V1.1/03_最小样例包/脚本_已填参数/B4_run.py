# -*- coding: utf-8 -*-
# 切割守恒校验：片段条数合计 = 原条数 + 2B × 切口数；多归属副本只校验内容一致
import json, glob, os, re

# ===== 参数区 =====
BASE = '/tmp/mini/base'
PROC = '/tmp/mini/过程包'
CUT = [3]
B = 3              # 单侧缓冲条数

def orig_count(wid):
    pats = glob.glob(f'{BASE}/*/{wid:03d}_*.json')
    if not pats: return None
    d = json.load(open(pats[0]))
    return len(d if isinstance(d, list) else d.get('messages', d))

bad, total_unique = [], 0
for wid in CUT:
    frags = glob.glob(f'{PROC}/*/*_{wid:03d}_片段*.json')
    uniq = {}
    for fp in frags:
        letter = (re.search(r'_片段([A-Z])_', os.path.basename(fp)) or [None, '?'])[1]
        d = json.load(open(fp))
        msgs = d if isinstance(d, list) else d.get('messages', d)
        if letter in uniq:
            if len(uniq[letter]) != len(msgs):
                bad.append(f'{wid:03d}片段{letter}: 副本条数不一致')
            continue
        uniq[letter] = msgs
    if not uniq:
        bad.append(f'{wid:03d}: 无片段!'); continue
    n_cuts = len(uniq) - 1
    got = sum(len(v) for v in uniq.values())
    expect = orig_count(wid) + 2 * B * n_cuts
    total_unique += len(uniq)
    print(f'{wid:03d}: {len(uniq)}片段 合计{got} 期望{expect} ' + ('OK' if got == expect else f'差{got-expect:+d}'))
    if got != expect:
        bad.append(f'{wid:03d}: 差{got-expect:+d}')
print(f'唯一片段总数: {total_unique} | 守恒通过: {len(CUT)-len(bad)}/{len(CUT)}')
