# -*- coding: utf-8 -*-
# 轮次化与逐轮统计：轮=连续人类消息组+紧随的AI回复组；三元组=AI回复含thinking块
import json, glob, os
import pandas as pd

# ===== 参数区（按本数据集填写）=====
BASE = '/tmp/mini/base'                 # 原始窗口JSON根目录
PACKAGES = ['包A', '包B']  # 来源分包列表
EXPECT_WINDOWS = 12                   # 预期窗口总数（0=不校验）
OUT_CSV = '/tmp/mini/逐轮统计明细.csv'

rows, no_reply, role_other = [], 0, set()
files = [fp for pk in PACKAGES for fp in glob.glob(f'{BASE}/{pk}/*.json')]
if EXPECT_WINDOWS:
    assert len(files) == EXPECT_WINDOWS, len(files)

for fp in sorted(files):
    wid = int(os.path.basename(fp).split('_')[0])
    d = json.load(open(fp))
    msgs = d if isinstance(d, list) else d.get('messages', d)
    groups = []
    for m in msgs:
        r = m.get('role')
        if r not in ('user', 'assistant'):
            role_other.add(r)
        texts = ''.join(c.get('content', '') or '' for c in m.get('contents', [])
                        if isinstance(c, dict) and c.get('type') == 'text')
        thinks = ''.join(c.get('content', '') or '' for c in m.get('contents', [])
                         if isinstance(c, dict) and c.get('type') == 'thinking')
        if groups and groups[-1][0] == r:
            groups[-1][1] += texts; groups[-1][2] += thinks; groups[-1][3] += 1
        else:
            groups.append([r, texts, thinks, 1])
    i, rnd = 0, 0
    while i < len(groups):
        g = groups[i]
        if g[0] == 'user':
            if i + 1 < len(groups) and groups[i+1][0] == 'assistant':
                a = groups[i+1]; rnd += 1
                rows.append({'窗口ID': wid, '轮次': rnd,
                             '人类字数': len(g[1]), '推理链字数': len(a[2]),
                             '回复字数': len(a[1]),
                             '轮次总字数': len(g[1]) + len(a[2]) + len(a[1]),
                             '三元组': '三元组' if len(a[2]) > 0 else '两元组',
                             '人类消息数': g[3], 'AI消息数': a[3]})
                i += 2
            else:
                no_reply += g[3]; i += 1
        else:
            i += 1

df = pd.DataFrame(rows)
df.to_csv(OUT_CSV, index=False, encoding='utf-8-sig')
total = len(df); tri = int((df['三元组'] == '三元组').sum())
print(f'总轮次: {total:,} | 三元组: {tri:,} ({tri/total*100:.1f}%) | '
      f'两元组: {total-tri:,} | 无回复消息: {no_reply} | 异常角色: {role_other or "无"}')
