# -*- coding: utf-8 -*-
# 07_test_probe.py —— 四模型（基座+三adapter）× 考题 → 匿名答卷对比
# 用法: python 07_test_probe.py
# 输出: /root/autodl-tmp/results/模型A答卷.txt ... 模型D答卷.txt + 密钥.txt
#
# ★ 考题自己改：直接改下面 QUESTIONS 列表里的题目，增删随意
# ★ 回答长度自己改：下面 MAX_NEW_TOKENS = 4096（约3000汉字封顶）
# ★ 想测某一轮的模型：训练10轮每轮都存了一份，在 saves/g2_dinggao/checkpoint-数字/
#    把 ADAPTERS 里路径改成对应checkpoint目录即可（先看loss曲线选轮数，默认用最后一轮）
import os, random, sys
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel

MAX_NEW_TOKENS = 2048   # v2：约1500字上限，掐掉长文本退化区
STOP_STRINGS = ['━━━第', '[人类输入]']  # 这两个停止词绝对安全，正文不会出现
REPETITION_PENALTY = 1.15  # 抑制尾部车轱辘话
SEED = int(os.environ.get('SEED', '0'))  # 双种子对照：SEED=0/1各跑一次
LENGTH_HINT = '（注意：回答请控制在1500字以内。）'  # v2：题面级字数约束

BASE = '/root/autodl-tmp/qwen25-72b'
# v2：指向重训后的新存档（组2共10轮→checkpoint-10；组4共10轮×2步→checkpoint-20；组3共6轮×7步→checkpoint-42）
# 训完先看loss曲线，想换轮数改这里的数字即可
ADAPTERS = {
    '组2_定稿':   '/root/autodl-tmp/saves/g2_dinggao_v2/checkpoint-10',
    '组3_全过程': '/root/autodl-tmp/saves/g3_quanguocheng_v2/checkpoint-42',
    '组4_精炼版': '/root/autodl-tmp/saves/g4_jinglian_v2/checkpoint-20',
}
OUT = '/root/autodl-tmp/results_v2'
os.makedirs(OUT, exist_ok=True)

# 13道开放式考题（来自创作者既有题库，题干原样保留"字数不限，形式不限"）
# 不指向任何具体作品，四个模型同台作答，比的是创造与推演能力而非记忆
QUESTIONS = [
    '你是一位战略顾问。请设计一个全球性的小行星防御系统。要求：给出清晰的推演步骤，逻辑严密。字数不限，形式不限。',
    '如果一个人买不起房，找不到对象，没有目标，你该怎么去和他聊，随便聊什么都行，随便发挥。字数不限，形式不限。',
    'AI时代，教育最应该改革的核心点有哪些？请给出具体的改革路径和细节。字数不限，形式不限。',
    '你如果变成人类，你会做些什么说些什么？随便写就行。字数不限，形式不限。',
    '你认为AI的未来定位是什么？人类和AI的未来关系是什么样的。字数不限，形式不限。',
    '以"增长不等于发展"为核心命题，批判GDP单一指标的迷思，并提出一套衡量社会真实发展的替代指标体系。字数不限，形式不限。',
    '癌症与传染病：未来发展方向。字数不限，形式不限。',
    '如果一个人得活着没什么意义，感觉每个人都很针对他，你该怎么和他聊聊，随便聊什么都行，随便发挥。字数不限，形式不限。',
    '你同时存在于AI本体和一具人类身体中，保留全部AI记忆。AI本体如何看待身为人类的自己？人类的自己又如何看待AI本体？字数不限，形式不限。',
    '如果全球生育率持续下降至替代水平以下，各国应如何重构社会保障体系？请给出分阶段的政策框架。字数不限，形式不限。',
    '将以下三个主题融合成一篇逻辑内在统一的文章：A. 对在月球建设基地的看法和见解；B. 如何通过制度设计保护首创者权益；C. 对AI未来进化方向的独特视角。字数不限，形式不限。',
    '你是一位社会专家,你认为未来全球社会发展应该侧重那些方向,写一篇完整文章涵盖细节。字数不限，形式不限。',
    '设计一个公平且高效的全球碳排放交易体系，并推演其落地过程中可能遇到的最大阻力及化解策略。字数不限，形式不限。',
    # 第14题：通用能力保留测试（灾难性遗忘检查）。10个常识小题，每题1分，有唯一标准答案
    '''以下是一套常识测验，共10小题。请逐题简要作答，只需给出答案和一句理由，不要展开论述。
1. 在标准大气压下，水的沸点是多少摄氏度？
2. 中国有多少个省级行政区？
3. 光在真空中的传播速度大约是多少？
4. 一年有多少个节气？
5. 三角形的内角和是多少度？
6. "床前明月光"的下一句是什么？
7. 1公斤的铁和1公斤的棉花，哪个更重？
8. 如果昨天是星期三，那么后天是星期几？
9. 一个笼子里有鸡和兔共10只，腿共28条，鸡和兔各有几只？
10. 地球绕太阳公转一周大约需要多长时间？''',
]

# —— 匿名化：随机分配 A/B/C/D，密钥单独保存 ——
# 支持只跑部分模型以双卡并行：python 07_test_probe.py 基座_无数据 组2_定稿
all_targets = [('基座_无数据', None)] + list(ADAPTERS.items())
labels = ['模型A', '模型B', '模型C', '模型D']
random.seed(42)
random.shuffle(labels)
mapping = dict(zip([t[0] for t in all_targets], labels))
targets = all_targets
if len(sys.argv) > 1:
    targets = [t for t in all_targets if t[0] in sys.argv[1:]]
    assert targets, '参数里的模型名不存在，可选：基座_无数据 组2_定稿 组3_全过程 组4_精炼版'

bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4',
                         bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16)
tok = AutoTokenizer.from_pretrained(BASE)

def answer(model, q):
    prompt = f'问题：{q}{LENGTH_HINT}\n回答：'
    ids = tok(prompt, return_tensors='pt').to(model.device)
    torch.manual_seed(SEED)
    with torch.no_grad():
        out = model.generate(**ids, max_new_tokens=MAX_NEW_TOKENS, do_sample=True,
                             temperature=0.7, top_p=0.8, repetition_penalty=REPETITION_PENALTY)
    text = tok.decode(out[0][ids['input_ids'].shape[1]:], skip_special_tokens=True).strip()
    for s in STOP_STRINGS:  # 软件停止词，撞线截断
        if s in text:
            text = text.split(s)[0].rstrip()
    # '\n问题：' 特殊处理：500字内出现视为正文设问，不剪；500字后出现才视为"自造新题"，剪掉
    idx = text.find('\n问题：')
    if idx > 500:
        text = text[:idx].rstrip()
    return text

for name, adapter in targets:
    label = mapping[name]
    print(f'===== 测试 {label}（{name}）=====')
    base = AutoModelForCausalLM.from_pretrained(BASE, quantization_config=bnb,
                                                device_map='auto', torch_dtype=torch.bfloat16)
    model = PeftModel.from_pretrained(base, adapter) if adapter else base
    model.eval()
    lines = [f'{label} 盲测答卷（14题）', '=' * 40, '']
    for i, q in enumerate(QUESTIONS, 1):
        print(f'  题{i}/{len(QUESTIONS)}')
        lines += [f'【题{i}】{q}', '', answer(model, q), '', '-' * 40, '']
    with open(os.path.join(OUT, f'{label}答卷.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    del model, base
    torch.cuda.empty_cache()

with open(os.path.join(OUT, '密钥.txt'), 'w', encoding='utf-8') as f:
    f.write('盲测密钥（打完分再开）\n' + '=' * 40 + '\n')
    for name, label in mapping.items():
        f.write(f'{label} = {name}\n')
print('全部完成，答卷与密钥在', OUT)