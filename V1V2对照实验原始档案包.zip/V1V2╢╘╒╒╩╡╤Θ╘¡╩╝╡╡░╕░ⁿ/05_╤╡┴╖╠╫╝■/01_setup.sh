#!/bin/bash
# 01_setup.sh —— 环境检查 + 依赖安装 + 模型下载
# 用法: bash 01_setup.sh
set -e

echo "===== [1/4] 检查PyTorch是否认出 RTX 6000D ====="
python - <<'EOF'
import torch
ok = torch.cuda.is_available()
print("cuda_available:", ok)
if ok:
    print("device:", torch.cuda.get_device_name(0))
    print("torch:", torch.__version__, "cuda:", torch.version.cuda)
    cap = torch.cuda.get_device_capability(0)
    print("capability:", cap)
    if cap[0] >= 12:
        v = tuple(int(x) for x in torch.__version__.split('+')[0].split('.')[:2])
        if v < (2, 7):
            raise SystemExit("!! PyTorch版本过低，不支持RTX 6000D。请换 PyTorch>=2.7 / CUDA>=12.8 的镜像重开实例")
    x = torch.randn(2048, 2048, device='cuda')
    y = (x @ x).sum().item()
    print("matmul ok:", y != 0)
else:
    raise SystemExit("!! CUDA不可用，请检查镜像")
EOF

echo "===== [2/4] 安装依赖 ====="
pip install -U bitsandbytes modelscope
pip install -U transformers datasets accelerate peft trl sentencepiece protobuf einops safetensors fire
cd /root/autodl-tmp
if [ ! -d LLaMA-Factory ]; then
  git clone --depth 1 https://github.com/hiyouga/LLaMA-Factory.git
fi
cd LLaMA-Factory
pip install -e . --no-deps
pip install -U bitsandbytes

echo "===== [3/4] 下载 Qwen2.5-72B 基座模型（约145G，支持断点续传） ====="
cd /root/autodl-tmp
modelscope download --model Qwen/Qwen2.5-72B --local_dir /root/autodl-tmp/qwen25-72b

echo "===== [4/4] 自检 ====="
python - <<'EOF'
import os
d = '/root/autodl-tmp/qwen25-72b'
need = ['config.json', 'tokenizer.json']
have = all(os.path.exists(os.path.join(d, f)) for f in need)
nsaf = len([f for f in os.listdir(d) if f.endswith('.safetensors')])
print("config/tokenizer:", have, "| safetensors分片:", nsaf)
assert have and nsaf >= 30, "!! 模型文件不完整，请重跑本脚本继续下载"
print("环境就绪，模型就绪")
EOF
