#!/bin/bash
# 06_run_all.sh —— 三组训练调度（带前置检查+自记录日志，失败必留痕）
# 全程日志写在 /root/autodl-tmp/run_all_log.txt
exec > /root/autodl-tmp/run_all_log.txt 2>&1
set -e
echo "===== 调度脚本启动: $(date) ====="

# 前置检查：三个训练配置必须在
for f in 03_train_g2.yaml 04_train_g4.yaml 05_train_g3.yaml; do
  if [ ! -f /root/autodl-tmp/$f ]; then
    echo "!! 缺少文件 /root/autodl-tmp/$f ，请重新上传该文件"
    exit 1
  fi
done
# 前置检查：LLaMA-Factory必须已安装
if [ ! -d /root/autodl-tmp/LLaMA-Factory ]; then
  echo "!! 未找到 LLaMA-Factory 目录，说明 01_setup.sh 没跑完，请先重新运行它"
  exit 1
fi
# 前置检查：模型必须在
if [ ! -f /root/autodl-tmp/qwen25-72b/config.json ]; then
  echo "!! 未找到模型 /root/autodl-tmp/qwen25-72b ，请检查模型下载"
  exit 1
fi
echo "前置检查通过"

cd /root/autodl-tmp/LLaMA-Factory
mkdir -p /root/autodl-tmp/saves

echo "===== 卡0训组2(定稿) & 卡1训组4(精炼版) 并行开始: $(date) ====="
CUDA_VISIBLE_DEVICES=0 llamafactory-cli train /root/autodl-tmp/03_train_g2.yaml > /root/autodl-tmp/logs_g2.txt 2>&1 &
P1=$!
CUDA_VISIBLE_DEVICES=1 llamafactory-cli train /root/autodl-tmp/04_train_g4.yaml > /root/autodl-tmp/logs_g4.txt 2>&1 &
P2=$!
wait $P1
echo "===== 组2完成: $(date) ====="
wait $P2
echo "===== 组4完成: $(date) ====="

echo "===== 组3(全过程)开始: $(date) ====="
CUDA_VISIBLE_DEVICES=0 llamafactory-cli train /root/autodl-tmp/05_train_g3.yaml > /root/autodl-tmp/logs_g3.txt 2>&1
echo "===== 组3完成: $(date) ====="

echo "===== 全部训练完成，结果在 /root/autodl-tmp/saves/ ====="
ls -la /root/autodl-tmp/saves/
