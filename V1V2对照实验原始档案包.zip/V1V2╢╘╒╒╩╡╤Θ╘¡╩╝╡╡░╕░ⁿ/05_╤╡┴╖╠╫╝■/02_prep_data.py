# -*- coding: utf-8 -*-
# 02_prep_data.py —— 把三个合集txt切块转成LLaMA-Factory预训练格式(jsonl)，并注册数据集
# 用法: python 02_prep_data.py
# 文件名自动识别：只要在 /root/autodl-tmp/ 下找到含"定稿"/"精炼"/"全过程"关键字的txt即可
import json, os, re, glob

DATA_ROOT = '/root/autodl-tmp'
LF_DATA = '/root/autodl-tmp/LLaMA-Factory/data'

# 组名: (文件名必须包含的关键字, 每块目标字符数)
# 块大小配合 cutoff_len=2048：1500汉字≈1200~1800 token，留有余量
GROUPS = {
    'dinggao_g2':      ('定稿', 1500),    # 组2 定稿
    'jinglian_g4':     ('精炼', 1500),    # 组4 精炼过程
    'quanguocheng_g3': ('全过程', 1500),  # 组3 全过程
}

def find_file(keyword):
    hits = [p for p in glob.glob(os.path.join(DATA_ROOT, '*.txt'))
            if keyword in os.path.basename(p)]
    assert hits, f'!! 在 {DATA_ROOT} 下没找到文件名含"{keyword}"的txt，请检查上传'
    return hits[0]

# v2 数据清洗开关
MASK_USER_TURNS = False  # True=组3脱敏净版：[人类输入]内容替换为占位符（默认False=保留原始内容）
COLLAPSE_REPEAT = True   # 压缩机械重复段（如语音转文字卡死产生的"很没意思×N"）

def clean_text(t, group_name=''):
    """v2：去说明头 + 还原转义换行 + 压缩机械重复 + 组3筛除格式标记。"""
    i = t.find('《')
    if i > 0:
        t = t[i:]
    # 1. 还原字面转义符（JSON导出残留）：\n \t
    t = t.replace('\\n', '\n').replace('\\t', '\t')
    # 2. 压缩机械重复：任意2~30字片段连续重复4遍以上 -> 保留2遍
    if COLLAPSE_REPEAT:
        t = re.sub(r'(.{2,30}?)\1{3,}', r'\1\1', t, flags=re.S)
    # 3. 组3全过程：筛除格式标记（轮次分隔线/时间戳/角色标签），保留原始内容
    if group_name == 'quanguocheng_g3':
        t = re.sub(r'━+第\d+轮━+\s*', '', t)          # ━━━第N轮━━━
        t = re.sub(r'\[时间\][^\n]*\n', '', t)          # [时间] 2026-xx-xx
        if MASK_USER_TURNS:
            t = re.sub(r'\[人类输入\].*?(?=\[AI推理链\])', '[提问]\n', t, flags=re.S)
        t = t.replace('[人类输入]', '').replace('[AI推理链]', '')
        t = t.replace('[AI回答]', '').replace('【AI回答】', '')
        t = re.sub(r'\n{3,}', '\n\n', t)                # 多余空行收拢
    return t

def chunk_text(t, target):
    """按段落累加切块，尽量不切断句子。"""
    paras = [p for p in re.split(r'\n\s*\n', t) if p.strip()]
    chunks, buf = [], ''
    for p in paras:
        if len(buf) + len(p) > target and buf:
            chunks.append(buf.strip())
            buf = ''
        buf += p + '\n\n'
    if buf.strip():
        chunks.append(buf.strip())
    return chunks

def main():
    info_path = os.path.join(LF_DATA, 'dataset_info.json')
    with open(info_path, encoding='utf-8') as f:
        info = json.load(f)

    for name, (keyword, target) in GROUPS.items():
        src = find_file(keyword)
        with open(src, encoding='utf-8') as f:
            t = clean_text(f.read(), name)
        chunks = chunk_text(t, target)
        out = os.path.join(LF_DATA, name + '.jsonl')
        with open(out, 'w', encoding='utf-8') as f:
            for c in chunks:
                f.write(json.dumps({'text': c}, ensure_ascii=False) + '\n')
        info[name] = {'file_name': name + '.jsonl', 'columns': {'prompt': 'text'}}
        total = sum(len(c) for c in chunks)
        print(f'{name}: 识别到[{os.path.basename(src)}] -> {len(chunks)}块, {total}字')

    with open(info_path, 'w', encoding='utf-8') as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
    print('数据准备完成，可以开始训练')

if __name__ == '__main__':
    main()
